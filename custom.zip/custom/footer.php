<footer class="smak">
        <div class="col-lg-12 wow slideInLeft" data-wow-delay="100ms">
            <div class="row text-center">
                <div class="col-lg-12 wow fadeInUp" data-wow-delay="100ms">
                    <p>© Copyright 2013 Smak. All Rights Reserved.</p>
                    <img src="img/footer_social_icon1.png" alt="">
                    <img src="img/footer_social_icon2.png" alt="">
                    <img src="img/footer_social_icon3.png" alt="">
                    <img src="img/footer_social_icon4.png" alt="">
                    <br>
                    <br>

                    <button class="btn" id="backtotop" href="#top">
                        <img src="img/nav_arrow_top.png" alt="">
                    </button>



                </div>
            </div>
        </div>
    </footer>


    <?php wp_footer(); ?>
</body>

</html>