<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Smak</title>
    <?php wp_head(); ?>
</head>

<body id="top">
    <span class="sr-only">Загрузка...</span>
    <header class="header">
        <div class="menu-top">
            <nav class="navbar navbar-expand-lg navbar-light">
                <div class="container">
                    <a class="navbar-brand" href="#">
                        <img src="http://custom/wp-content/uploads/2022/02/logo.png" alt="">
                    </a>

                    <button class="navbar-toggler" type="button" data-toggle="collapse"
                        data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <?php wp_nav_menu( [
	'theme_location'  => 'top',
	'container'       => false, 
	'menu_class'      => 'navbar-nav ml-auto', 
	'menu_id'         => '',
] ); ?>
                        <!-- <ul class="navbar-nav ml-auto">
                            <li class="nav-item active">
                                <a class="nav-link" href="#top">Home
                                    <span class="sr-only">(current)</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#services">services</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#work">work</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#about">about</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#clients"> clients</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#con">contact</a>
                            </li>
                        </ul> -->
                    </div>
            </nav>
        </div>
        </div>
        <div class="flex wow flipInX" data-wow-delay="200ms">
            <div class="center">
                <h1>branding have another
                    <br> definition
                </h1>
                <buttan class="btn-yellow">
                    buy this theme
                </buttan>
            </div>
        </div>
    </header>