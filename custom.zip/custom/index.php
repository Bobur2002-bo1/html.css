<?php get_header(); ?>
<section class="service" id="services">
    <div class="container wow slideInLeft" data-wow-delay="200ms">
        <div class="row">
            <div class="col-lg-12 wow fadeInUp" data-wow-delay="300ms">
                <h5>our services</h5>
                <h3>what we love to do</h3>
                <hr>
                <p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Vivamus suscipit tortor eget
                    felis
                    porttitor volutpat. Curabitur aliquet quam id dui posuere blandit. Nulla porttitor
                    <br> accumsan tincidunt. Cras ultricies ligula sed magna dictum porta. Curabitur non nulla sit
                    amet nisl
                    tempus convallis quis ac lectus. Praesent sapien massa, convallis a pellen
                    <br> tesque nec, egestas non nisi. Mauris blandit aliquet elit, eget tincidunt ni dictum porta.
                </p>
            </div>
        </div>
        <div class="row text-center">
            <div class="col-lg-3 col-md-3 col-sm-6 wow slideInRight" data-wow-delay="300ms">
                <div class="round">

                    <i class="fa fa-css3" aria-hidden="true"></i>
                </div>

                <h4>web design</h4>
                <p>Donec sollicitudin molestie malesuada. Curabitur aliquet quam id dui posuere blandit.</p>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 wow slideInLeft" data-wow-delay="400ms">
                <div class="round">
                    <i class="fa fa-pencil" aria-hidden="true"></i>
                </div>

                <h4>web design</h4>
                <p>Donec sollicitudin molestie malesuada. Curabitur aliquet quam id dui posuere blandit.</p>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 wow slideInRight" data-wow-delay="500ms">
                <div class="round">
                    <i class="fa fa-camera" aria-hidden="true"></i>
                </div>

                <h4>web design</h4>
                <p>Donec sollicitudin molestie malesuada. Curabitur aliquet quam id dui posuere blandit.</p>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 wow slideInLeft" data-wow-delay="600ms">
                <div class="round">
                    <i class="fa fa-cog" aria-hidden="true"></i>
                </div>
                <h4>web design</h4>
                <p>Donec sollicitudin molestie malesuada. Curabitur aliquet quam id dui posuere blandit.</p>
            </div>
        </div>
    </div>
</section>
<section class="do-it">
    <div class="container wow rotateIn" data-wow-delay="200ms">
        <div class="row">
            <div class="col-lg-12 wow fadeInUp" data-wow-delay="300ms">
                <h3>how we do it</h3>
                <p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Vivamus suscipit tortor eget
                    felis
                    porttitor volutpat.</p>
            </div>
        </div>
        <div class="row text-center">
            <div class="col-lg-2 col-md-4 col-sm-6 wow fadeInUp" data-wow-delay="400ms">
                <div class="it">
                    <img src="img/services_icon1.png" alt="">

                </div>
                <h4>analyse</h4>
                <p>Vivamus suscipit tortor eget felis porttitor volutpat. Cura bitur aliquet quam.</p>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-6 wow fadeInUp" data-wow-delay="500ms">
                <div class="it">
                    <img src="img/services_icon2.png" alt="">

                </div>
                <h4>preparing</h4>
                <p>Vivamus suscipit tortor eget felis porttitor volutpat. Cura bitur aliquet quam id dui posu ere
                    blandit</p>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-6 wow fadeInUp" data-wow-delay="600ms">
                <div class="it">
                    <img src="img/services_icon3.png" alt="">

                </div>
                <h4>working</h4>
                <p>Vivamus suscipit tortor eget felis porttitor volutpat.</p>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-6 wow fadeInUp" data-wow-delay="700ms">
                <div class="it-roll">
                    <i class="fa fa-cog fa-spin fa-3x fa-fw">
                    </i>
                    <span class="sr-only">Загрузка...</span>
                </div>
                <h4>finalyse</h4>
                <p>Vivamus suscipit tortor eget felis porttitor volutpat. Cura bitur aliquet quam id.</p>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-6 wow fadeInUp" data-wow-delay="800ms">
                <div class="it-roll">
                    <i class="fa fa-spinner fa-spin fa-3x fa-fw"></i>
                    <span class="sr-only">Загрузка...</span>
                </div>
                <h4>testing</h4>
                <p>Vivamus suscipit tortor eget felis porttitor volutpat. Cura bitur aliquet quam id dui posu ere
                    blandit</p>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-6 wow fadeInUp" data-wow-delay="900ms">
                <div class="it">
                    <img src="img/services_icon6.png" alt="">

                </div>
                <h4>deliver</h4>
                <p>Vivamus suscipit tortor eget felis porttitor volutpat. Cur est bitur.</p>
            </div>

        </div>
    </div>
</section>
<section class="works" id="work">
    <div class="container wow slideInLeft" data-wow-delay="200ms">
        <div class="row text-center">
            <div class="col-lg-12 wow fadeInUp" data-wow-delay="300ms">
                <h5>our works</h5>
                <h3>what we done so far</h3>
                <hr>
                <p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Vivamus suscipit tortor eget
                    felis
                    porttitor volutpat. Curabitur aliquet quam id dui posuere blandit. Nulla porttitor accumsan
                    tincidunt.
                    Cras ultricies ligula sed magna dictum porta. Curabitur non nulla sit amet nisl tempus
                    convallis
                    quis ac lectus. Praesent sapien massa, convallis a pellen tesque nec, egestas non nisi. Mauris
                    blandit
                    aliquet elit, eget tincidunt ni dictum porta.</p>
            </div>

        </div>
        <div class="row">
            <div class="col-lg-12 wow fadeInUp" data-wow-delay="400ms">
                <ul class="nav justify-content-center" id="myTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab"
                            aria-controls="home" aria-selected="true">all</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab"
                            aria-controls="profile" aria-selected="false">web design</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab"
                            aria-controls="contact" aria-selected="false">graphic design</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="contact-tab2" data-toggle="tab" href="#contact2" role="tab"
                            aria-controls="contact" aria-selected="false">photography</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="contact-tab3" data-toggle="tab" href="#contact3" role="tab"
                            aria-controls="contact" aria-selected="false">illustration</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                <div class="row text-align-center wow fadeInUp" data-wow-delay="100ms">
                    <div class="col-lg-7">
                        <img src="img/header_bg.jpg" alt="">
                    </div>
                    <div class="col-lg-5 wow fadeInUp" data-wow-delay="200ms">
                        <h4>Our Awesome Image</h4>
                        <p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Vivamus suscipit
                            tortor eget
                            felis porttitor volutpat. Curabitur aliquet quam id dui posuere blandit. Nulla
                            porttitor
                            accumsan tinci dunt. Cras ultricies ligula sed magna dictum porta. Curabitur non nulla
                            sit
                            amet nisl tempus convallis quis ac lectus. Praesent sapien massa, convallis a
                            pellentesque
                            nec, egestas non nisi. Mauris blan dit aliquet elit, eget tincidunt ni dictum porta.</p>
                        <button class="btn yellow">View Live </button>


                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                <div class="row text-align-center">
                    <div class="col-lg-7 wow fadeInUp" data-wow-delay="100ms">

                        <h4>Our Awesome Image</h4>
                        <p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Vivamus suscipit
                            tortor eget
                            felis porttitor volutpat. Curabitur aliquet quam id dui posuere blandit. Nulla
                            porttitor
                            accumsan tinci dunt. Cras ultricies ligula sed magna dictum porta. Curabitur non nulla
                            sit
                            amet nisl tempus convallis quis ac lectus. Praesent sapien massa, convallis a
                            pellentesque
                            nec, egestas non nisi. Mauris blan dit aliquet elit, eget tincidunt ni dictum porta.</p>
                        <button class="btn yellow">View Live </button>
                    </div>
                    <div class="col-lg-5 wow fadeInUp" data-wow-delay="200ms">
                        <img src="img/howwedobg.jpg" alt="">
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                <div class="row text-align-center">
                    <div class="col-lg-7 wow fadeInUp" data-wow-delay="100ms">
                        <img src="img/header_bg.jpg" alt="">
                    </div>
                    <div class="col-lg-5 wow fadeInUp" data-wow-delay="200ms">
                        <h4>Our Awesome Image</h4>
                        <p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Vivamus suscipit
                            tortor eget
                            felis porttitor volutpat. Curabitur aliquet quam id dui posuere blandit. Nulla
                            porttitor
                            accumsan tinci dunt. Cras ultricies ligula sed magna dictum porta. Curabitur non nulla
                            sit
                            amet nisl tempus convallis quis ac lectus. Praesent sapien massa, convallis a
                            pellentesque
                            nec, egestas non nisi. Mauris blan dit aliquet elit, eget tincidunt ni dictum porta.</p>
                        <button class="btn yellow">View Live </button>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="contact2" role="tabpanel" aria-labelledby="contact-tab">
                <div class="row text-align-center">
                    <div class="col-lg-7" data-wow-delay="100ms">

                        <h4>Our Awesome Image</h4>
                        <p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Vivamus suscipit
                            tortor eget
                            felis porttitor volutpat. Curabitur aliquet quam id dui posuere blandit. Nulla
                            porttitor
                            accumsan tinci dunt. Cras ultricies ligula sed magna dictum porta. Curabitur non nulla
                            sit
                            amet nisl tempus convallis quis ac lectus. Praesent sapien massa, convallis a
                            pellentesque
                            nec, egestas non nisi. Mauris blan dit aliquet elit, eget tincidunt ni dictum porta.</p>
                        <button class="btn yellow">View Live </button>
                    </div>
                    <div class="col-lg-5 wow fadeInUp" data-wow-delay="200ms">
                        <img src="img/proudbg.jpg" alt="">
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="contact3" role="tabpanel" aria-labelledby="contact-tab">
                <div class="row text-align-center">
                    <div class="col-lg-7 wow fadeInUp" data-wow-delay="100ms">
                        <img src="img/header_bg.jpg" alt="">
                    </div>
                    <div class="col-lg-5 wow fadeInUp" data-wow-delay="200ms">
                        <h4>Our Awesome Image</h4>
                        <p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Vivamus suscipit
                            tortor eget
                            felis porttitor volutpat. Curabitur aliquet quam id dui posuere blandit. Nulla
                            porttitor
                            accumsan tinci dunt. Cras ultricies ligula sed magna dictum porta. Curabitur non nulla
                            sit
                            amet nisl tempus convallis quis ac lectus. Praesent sapien massa, convallis a
                            pellentesque
                            nec, egestas non nisi. Mauris blan dit aliquet elit, eget tincidunt ni dictum porta.</p>
                        <button class="btn yellow">View Live </button>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>


<section class="pics wow slideInRight" data-wow-delay="100ms">
    <div class="col-lg-12">
        <div class="row">
            <div class="col-lg-2 col-md-3 col-sm-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="200ms">
                <img src="img/portfolio_image1.jpg" alt="">
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="300ms">
                <img src="img/portfolio_image2.jpg" alt="">
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="400ms">
                <img src="img/portfolio_image3.jpg" alt="">
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="500ms">
                <img src="img/portfolio_image4.jpg" alt="">
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="600ms">
                <img src="img/portfolio_image5.jpg" alt="">
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="700ms">
                <img src="img/portfolio_image6.jpg" alt="">
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="800ms">
                <img src="img/portfolio_image6.jpg" alt="">
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="900ms">
                <img src="img/portfolio_image5.jpg" alt="">
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="1000ms">
                <img src="img/portfolio_image4.jpg" alt="">
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="1100ms">
                <img src="img/portfolio_image3.jpg" alt="">
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="1200ms">
                <img src="img/portfolio_image2.jpg" alt="">
            </div>
            <div class="col-lg-2 col-md-3 col-sm-4 col-sm-6 col-6 wow fadeInUp" data-wow-delay="1300ms">
                <img src="img/portfolio_image1.jpg" alt="">
            </div>
        </div>
    </div>
</section>


<section class="portfolio wow slideInLeft" data-wow-delay="100ms">
    <div class="col-lg-12">
        <div class="row">
            <div class="col-lg-12 text-center wow fadeInUp" data-wow-delay="200ms">
                <img src="img/slider_arrow_right.png" alt="">
                <h3>do you like our portfolio?</h3>
                <p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Vivamus suscipit tortor eget
                    felis porttitor
                    volutpat. Curabitur aliquet quam id dui posuere.</p>
                <button class="btn yellow"> contact us</button>
            </div>
        </div>
    </div>
</section>


<section class="proud wow slideInRight" data-wow-delay="100ms">
    <div class="container">
        <div class="row text-center">
            <div class="col-lg-12 wow fadeInUp" data-wow-delay="200ms">
                <h3>we are proud of these numbers</h3>
                <p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Vivamus suscipit tortor eget
                    felis
                    porttitor volutpat. Curabitur aliquet quam id dui posuere.</p>
            </div>
            <?php $numbers = new WP_Query(array('post_type' => 'numbers' ,'posts_per_page' => -1)); ?>
            <?php if ($numbers->have_posts()) : while ($numbers->have_posts()) : $numbers->the_post();  ?>
            <div class="col-lg-3 col-md-6 col-sm-6 wow fadeInUp" data-wow-delay="300ms">
                <div class="proud-box-a">
                    <div class="number counter"><?php the_title(); ?></div>
                    <h5><?php the_content(); ?></h5>
                </div>
            </div>
            <?php endwhile; endif;  ?>

        </div>
    </div>
</section>


<section class="about" id="about">
    <div class="col-lg-12 wow slideInLeft" data-wow-delay="100ms">
        <div class="row">
            <div class="col-lg-12 text-center wow fadeInUp" data-wow-delay="200ms">
                <h5>about us</h5>
                <h3>who we are</h3>
                <hr>
                <p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Vivamus suscipit tortor eget
                    felis porttitor
                    volutpat. Curabitur aliquet quam id dui posuere blandit. Nulla porttitor
                    <br> accumsan tincidunt. Cras ultricies ligula sed magna dictum porta. Curabitur non nulla sit
                    amet nisl
                    tempus convallis quis ac lectus. Praesent sapien massa, convallis a pellen
                    <br> tesque nec, egestas non nisi. Mauris blandit aliquet elit, eget tincidunt ni dictum porta.
                </p>
            </div>
        </div>
        <div class="container">
            <div class="row text-center">
                <div class="col-lg-6 col-md-6 sss wow fadeInUp" data-wow-delay="300ms">
                    <div class="about-box">
                        <div class="row">
                            <div class="box text-center">
                                <img src="img/about_icon1.png" alt="">
                            </div>

                        </div>
                        <h5>on time projects</h5>
                        <p>Praesent sapien massa, convallis a pellentesque nec, egestas non nisi.
                            <br> Mauris blandit aliquet elit, eget tincidunt ni dictum porta.
                            <br> Cras ultricies ligula sed magna dictum est ontar des lorem ipsum.
                        </p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="400ms">
                    <div class="about-box">
                        <div class="row">
                            <div class="box">
                                <img src="img/about_icon2.png" alt="">
                            </div>
                        </div>
                        <h5>fully support</h5>
                        <p>Praesent sapien massa, convallis a pellentesque nec, egestas non nisi.
                            <br> Mauris blandit aliquet elit, eget tincidunt ni dictum porta.
                            <br> Cras ultricies ligula sed magna dictum est ontar des lorem ipsum.
                        </p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="500ms">
                    <div class="about-box">
                        <div class="row">
                            <div class="box">
                                <img src="img/about_icon3.png" alt="">
                            </div>
                        </div>
                        <h5>on time projects</h5>
                        <p>Praesent sapien massa, convallis a pellentesque nec, egestas non nisi.
                            <br> Mauris blandit aliquet elit, eget tincidunt ni dictum porta.
                            <br> Cras ultricies ligula sed magna dictum est ontar des lorem ipsum.
                        </p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="600ms">
                    <div class="about-box">
                        <div class="row">
                            <div class="box">
                                <img src="img/about_icon4.png" alt="">
                            </div>
                        </div>
                        <h5>fully support</h5>
                        <p>Praesent sapien massa, convallis a pellentesque nec, egestas non nisi.
                            <br> Mauris blandit aliquet elit, eget tincidunt ni dictum porta.
                            <br> Cras ultricies ligula sed magna dictum est ontar des lorem ipsum.
                        </p>
                    </div>
                </div>
            </div>
        </div>
</section>


<section class="team wow slideInRight" data-wow-delay="100ms">
    <div class="col-lg-12">
        <div class="row text-center">
            <div class="col-lg-12 wow fadeInUp" data-wow-delay="200ms">
                <h3>the team</h3>
                <p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus.
                    <br> Vivamus suscipit tortor eget felis porttitor volutpat.
                    <br> Curabitur aliquet quam id dui posuere.
                </p>
            </div>
            <div class="container">
                <div class="row">
                <?php $team = new WP_Query(array('post_type' => 'team' ,'posts_per_page' => -1)); ?>
            <?php if ($team->have_posts()) : while ($team->have_posts()) : $team->the_post();  ?>
                    <div class="col-lg-3 col-md-6 col-sm-6 wow fadeInUp" data-wow-delay="100ms"> 
                    <div class="top">
                    <?php the_post_thumbnail(); ?>
                            <h4><?php the_title(); ?></h4>
                            <h5><?php the_content(); ?></h5>
                        </div>
                    </div>
                    <?php endwhile; endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="doe wow slideInLeft" data-wow-delay="100ms">
    <div class="container text-center">
        <div class="row">
            <div class="col-lg-12 wow fadeInUp" data-wow-delay="200ms">
                <div class="john">
                    <h3>john doe</h3>
                </div>
                <div class="x d-flex justify-content-end">
                    <img src="img/x_icon.png" alt="">
                </div>
                <p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Vivamus suscipit tortor
                    eget
                    felis porttitor
                    volutpat. Curabitur aliquet quam id
                    <br> dui posuere blandit. Nulla porttitor accumsan tincidunt. Cras ultricies ligula sed
                    magna
                    dictum porta.
                    Curabitur non nulla sit amet nisl tempus
                    <br> convallis quis ac lectus. Praesent sapien massa, convallis a pellentesque nec, egestas
                    non
                    nisi. Mauris
                    blandit aliquet elit, eget tincidunt ni
                    <br> dictum porta.
                </p>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 text-center wow fadeInUp" data-wow-delay="300ms">
                <div class="img">
                    <img src="img/facebook_icon.png" alt="">
                    <img src="img/twitter_icon.png" alt="">
                </div>
            </div>
        </div>
    </div>
</section>


<section class="skills wow slideInRight" data-wow-delay="100ms">
    <div class="col-lg-12">
        <div class="row text-center">
            <div class="col-lg-12 wow fadeInUp" data-wow-delay="200ms">
                <h3>skills</h3>
                <p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Vivamus suscipit tortor eget
                    felis porttitor
                    volutpat. Curabitur aliquet quam id dui posuere.</p>
            </div>
            <div class="container">
                <div class="row text-center">
                    <div class="col-lg-3 col-md-6 col-sm-6 wow fadeInUp" data-wow-delay="300ms">
                        <div class="round">
                            <p><span class="counter">90 </span>%</p>
                            <h5>html&css</h5>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6 wow fadeInUp" data-wow-delay="400ms">
                        <div class="round">
                            <p><span class="counter">96</span>%</p>
                            <h5>ai & ps</h5>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6 wow fadeInUp" data-wow-delay="500ms">
                        <div class="round">
                            <p><span class="counter">85</span>%</p>
                            <h5>js & php</h5>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6 wow fadeInUp" data-wow-delay="600ms">
                        <div class="round">
                            <p><span class="counter">95</span>%</p>
                            <h5>photography</h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="clients" id="clients">
    <div class="col-lg-12  wow slideInLeft" data-wow-delay="100ms">
        <div class="row text-center">
            <div class="col-lg-12 wow fadeInUp" data-wow-delay="200ms">
                <h5>our clients</h5>
                <h3>who love to work with us</h3>
                <hr>
                <p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Vivamus suscipit tortor eget
                    felis porttitor
                    volutpat. Curabitur aliquet quam id dui posuere blandit. Nulla porttitor
                    <br> accumsan tincidunt. Cras ultricies ligula sed magna dictum porta. Curabitur non nulla sit
                    amet nisl
                    tempus convallis quis ac lectus. Praesent sapien massa, convallis a pellen
                    <br> tesque nec, egestas non nisi. Mauris blandit aliquet elit, eget tincidunt ni dictum porta.
                </p>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-2 col-md-2 col-sm-4 wow fadeInUp" data-wow-delay="100ms">
                        <img src="img/clients_logo1.png" alt="">
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-4 wow fadeInUp" data-wow-delay="200ms">
                        <img src="img/clients_logo2.png" alt="">
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-4 wow fadeInUp" data-wow-delay="300ms">
                        <img src="img/clients_logo3.png" alt="">
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-4 wow fadeInUp" data-wow-delay="400ms">
                        <img src="img/clients_logo4.png" alt="">
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-4 wow fadeInUp" data-wow-delay="500ms">
                        <img src="img/clients_logo5.png" alt="">
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-4 wow fadeInUp" data-wow-delay="600ms">
                        <img src="img/clients_logo1.png" alt="">
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>


<section class="daniel">
    <div class="col-lg-12 wow slideInRight" data-wow-delay="100ms">
        <div class="row text-center">
            <div class="col-lg-12">

                <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="pills-home" role="tabpanel"
                        aria-labelledby="pills-home-tab">“An
                        image is not simply a trademark, a design, a slogan or an easily
                        <br> remembered picture. It is a studiously crafted personality profile of an
                        <br> individual, institution,corporation, product or service”
                    </div>
                    <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                        “An
                        image is not simply a trademark, a design, a slogan or an easily
                        <br> remembered picture. It is a studiously crafted personality profile of an
                        <br> individual, institution,corporation, product or service”
                    </div>
                    <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
                        “An
                        image is not simply a trademark, a design, a slogan or an easily
                        <br> remembered picture. It is a studiously crafted personality profile of an
                        <br> individual, institution,corporation, product or service”
                    </div>


                    <hr>
                    <p>Daniel J. Boorstin</p>
                    <div class="row justify-content-center">
                        <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home"
                                    role="tab" aria-controls="pills-home" aria-selected="true">
                                    <button class="btn"></button>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile"
                                    role="tab" aria-controls="pills-profile" aria-selected="false">
                                    <button class="btn"></button>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact"
                                    role="tab" aria-controls="pills-contact" aria-selected="false">
                                    <button class="btn"></button>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
</section>


<section class="contact" id="con">
    <div class="col-lg-12 wow slideInLeft" data-wow-delay="100ms">
        <div class="row text-center">
            <div class="col-lg-12 wow fadeInUp" data-wow-delay="200ms">
                <h5>contact us</h5>
                <h3>where you can find us</h3>
                <hr>
                <p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Vivamus suscipit tortor eget
                    felis porttitor
                    volutpat. Curabitur aliquet quam id dui posuere blandit. Nulla porttitor
                    <br> accumsan tincidunt. Cras ultricies ligula sed magna dictum porta. Curabitur non nulla sit
                    amet nisl
                    tempus convallis quis ac lectus. Praesent sapien massa, convallis a pelle
                    <br> ntesque nec, egestas non nisi. Mauris blandit aliquet elit, eget tincidunt ni dictum
                    porta.
                </p>
            </div>
        </div>
        <div class="container">
            <div class="row text-center">
                <div class="col-lg-4 col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="100ms">
                    <img src="img/contact_icon1.png" alt="">
                    <h5>our address</h5>
                    <p>214 Awesome Street,NY</p>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="200ms">
                    <img src="img/contact_icon2.png" alt="">
                    <h5>our mail</h5>
                    <p>awesomemail@ourmail.com</p>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="300ms">
                    <img src="img/contact_icon3.png" alt="">
                    <h5>our phone</h5>
                    <p>(0) 123-456-789-00</p>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="message">
    <div class="col-lg-12 wow slideInRight" data-wow-delay="100ms">
        <div class="row text-center">
            <div class="col-lg-12 wow fadeInUp" data-wow-delay="200ms">
                <h4>send us a message</h4>
                <p>Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Vivamus suscipit tortor eget
                    felis porttitor
                    volutpat. Curabitur aliquet quam id dui posuere.</p>
                <div class="container">
                    <div class="col-lg-12 wow fadeInUp" data-wow-delay="100ms">
                        <form>
                            <div class="form-row">
                                <div class="col wow fadeInUp" data-wow-delay="100ms">
                                    <input type="text" class="form-control" placeholder="Your name">
                                </div>
                                <div class="col wow fadeInUp" data-wow-delay="200ms">
                                    <input type="text" class="form-control" placeholder="Your mail">
                                </div>
                                <div class="col wow fadeInUp" data-wow-delay="300ms">
                                    <input type="text" class="form-control" placeholder="Sabject">
                                </div>
                            </div>

                        </form>
                    </div>

                    <form>
                        <div class="col wow fadeInUp" data-wow-delay="400ms">
                            <input type="text" class="form-control" placeholder="Enter messaje Here....">
                        </div>
                    </form>
                </div>


                <button class="btn wow fadeInUp" data-wow-delay="500ms">send message</button>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>