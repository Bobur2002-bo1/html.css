<?php
add_action('wp_enqueue_scripts', 'theme_style');
add_action('wp_enqueue_scripts', 'theme_script');
add_action('after_setup_theme', 'theme_menu');
add_action('init', 'register_entry');



function register_entry()  { 
    register_post_type('numbers', [
		'label'  => null,
		'labels' => [
			'name'               => 'numbers', // основное название для типа записи
			'singular_name'      => 'numbers', // название для одной записи этого типа
			'add_new'            => 'Добавить numbers', // для добавления новой записи
			'add_new_item'       => 'Добавление numbers', // заголовка у вновь создаваемой записи в админ-панели.
			'edit_item'          => 'Редактирование numbers', // для редактирования типа записи
			'new_item'           => 'Новое numbers', // текст новой записи
			'view_item'          => 'Смотреть numbers', // для просмотра записи этого типа.
			'search_items'       => 'Искать numbers', // для поиска по этим типам записи
			'not_found'          => 'Не найдено', // если в результате поиска ничего не было найдено
			'not_found_in_trash' => 'Не найдено в корзине', // если не было найдено в корзине
			'parent_item_colon'  => '', // для родителей (у древовидных типов)
			'menu_name'          => 'Numbers', // название меню
		],
		'description'         => 'Работа в numbers',
		'public'              => true,
		'publicly_queryable'  => true, // зависит от public
		'exclude_from_search' => false, // зависит от public
		'show_ui'             => true, // зависит от public
		'show_in_nav_menus'   => true, // зависит от public
		'show_in_menu'        => true, // показывать ли в меню адмнки
		'show_in_admin_bar'   => true, // зависит от show_in_menu
		'show_in_rest'        => null, // добавить в REST API. C WP 4.7
		'rest_base'           => null, // $post_type. C WP 4.7
		'menu_position'       => null,
		'menu_icon'           => null,
		//'capability_type'   => 'post',
		//'capabilities'      => 'post', // массив дополнительных прав для этого типа записи
		//'map_meta_cap'      => null, // Ставим true чтобы включить дефолтный обработчик специальных прав
		'hierarchical'        => false,
		'supports'            => ['title', 'editor', 'thumbnail', 'post-formats'],
		// 'title','editor','author','thumbnail','excerpt','trackbacks','custom-fields','comments','revisions','page-attributes'
		'taxonomies'          => [],
		'has_archive'         => false,
		'rewrite'             => true,
		'query_var'           => true,
	]);
    register_post_type('team', [
		'label'  => null,
		'labels' => [
			'name'               => 'team', // основное название для типа записи
			'singular_name'      => 'team', // название для одной записи этого типа
			'add_new'            => 'Добавить team', // для добавления новой записи
			'add_new_item'       => 'Добавление team', // заголовка у вновь создаваемой записи в админ-панели.
			'edit_item'          => 'Редактирование team', // для редактирования типа записи
			'new_item'           => 'Новое team', // текст новой записи
			'view_item'          => 'Смотреть team', // для просмотра записи этого типа.
			'search_items'       => 'Искать team', // для поиска по этим типам записи
			'not_found'          => 'Не найдено', // если в результате поиска ничего не было найдено
			'not_found_in_trash' => 'Не найдено в корзине', // если не было найдено в корзине
			'parent_item_colon'  => '', // для родителей (у древовидных типов)
			'menu_name'          => 'Team', // название меню
		],
		'description'         => 'Работа в team',
		'public'              => true,
		'publicly_queryable'  => true, // зависит от public
		'exclude_from_search' => false, // зависит от public
		'show_ui'             => true, // зависит от public
		'show_in_nav_menus'   => true, // зависит от public
		'show_in_menu'        => true, // показывать ли в меню адмнки
		'show_in_admin_bar'   => true, // зависит от show_in_menu
		'show_in_rest'        => null, // добавить в REST API. C WP 4.7
		'rest_base'           => null, // $post_type. C WP 4.7
		'menu_position'       => null,
		'menu_icon'           => null,
		//'capability_type'   => 'post',
		//'capabilities'      => 'post', // массив дополнительных прав для этого типа записи
		//'map_meta_cap'      => null, // Ставим true чтобы включить дефолтный обработчик специальных прав
		'hierarchical'        => false,
		'supports'            => ['title', 'editor', 'thumbnail', 'post-formats'],
		// 'title','editor','author','thumbnail','excerpt','trackbacks','custom-fields','comments','revisions','page-attributes'
		'taxonomies'          => [],
		'has_archive'         => false,
		'rewrite'             => true,
		'query_var'           => true,
	]);
}
function theme_menu()
{
	register_nav_menu('top', 'Меню в шапке');
	register_nav_menu('bottom', 'Меню в подвале');
    add_theme_support('post-thumbnails', array('post', 'team'));
}


function theme_style()
{
	wp_enqueue_style('style', get_stylesheet_uri());
	wp_enqueue_style('bootstrapmincss', get_template_directory_uri() . '/assets/css/bootstrap.min.css');
	wp_enqueue_style('fonts', get_template_directory_uri() . '/assets/css/fonts.css');
	wp_enqueue_style('pe-icon-7-stroke.css', get_template_directory_uri() . '/assets/css/pe-icon-7-stroke.css');
    wp_enqueue_style('animate.css', get_template_directory_uri() . '/assets/wow/animate.css');
    wp_enqueue_style('font-awesome.css', get_template_directory_uri() . '/assets/css/font-awesome.css');
    wp_enqueue_style('style.css', get_template_directory_uri() . '/assets/css/style.css');
}

function theme_script()
{
	wp_deregister_script('jquery');
	wp_register_script('jquery', '//ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js');
	wp_enqueue_script('jquery');
	wp_enqueue_script('popper.js', get_template_directory_uri() . '/assets/js/popper.js', ['jquery'], null, true);
	wp_enqueue_script('bootstrap.js', get_template_directory_uri() . '/assets/js/bootstrap.js', ['jquery'], null, true);
	wp_enqueue_script('backtotopjs', get_template_directory_uri() . '/assets/js/jquery.backtotop.js', ['jquery'], null, true);
	wp_enqueue_script('wow.min.js', get_template_directory_uri() . '/assets/wow/wow.min.js', false, null, false);
    wp_enqueue_script('jquery.counterup', get_template_directory_uri() . '/assets/js/jquery.counterup.min.js', false, null, false);
    wp_enqueue_script('script.js', get_template_directory_uri() . '/assets/js/script.js', false, null, false);
    wp_enqueue_script('waypoints', '"//cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js');
}